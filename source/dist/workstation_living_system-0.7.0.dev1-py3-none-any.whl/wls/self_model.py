from __future__ import annotations

from typing import Any
import json

from .db import Database
from .evidence import EvidenceLedger
from .schemas import ActionResult, ActionSpec, utc_now


class SelfModel:
    """Evidence-bound model of capabilities, limits, permissions, and commitments."""

    def __init__(self, db: Database, ledger: EvidenceLedger):
        self.db = db
        self.ledger = ledger

    def set(
        self, key: str, value: Any, confidence: float, evidence_ids: list[str]
    ) -> None:
        if not evidence_ids:
            raise ValueError("self-model updates require evidence")
        confidence = max(0.0, min(1.0, confidence))
        with self.db.transaction() as connection:
            connection.execute(
                """
                INSERT INTO self_model(key,value_json,confidence,evidence_ids_json,updated_at)
                VALUES (?,?,?,?,?)
                ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json,
                    confidence=excluded.confidence,evidence_ids_json=excluded.evidence_ids_json,
                    updated_at=excluded.updated_at
                """,
                (
                    key,
                    json.dumps(value, ensure_ascii=False, sort_keys=True),
                    confidence,
                    json.dumps(evidence_ids, ensure_ascii=False),
                    utc_now(),
                ),
            )
            self.ledger.append(
                "self_model_updated",
                {
                    "key": key,
                    "value": value,
                    "confidence": confidence,
                    "evidence_ids": evidence_ids,
                },
                connection,
            )

    def snapshot(self) -> dict[str, Any]:
        rows = self.db.query_all("SELECT * FROM self_model ORDER BY key")
        return {
            row["key"]: {
                "value": json.loads(row["value_json"]),
                "confidence": float(row["confidence"]),
                "evidence_ids": json.loads(row["evidence_ids_json"]),
                "updated_at": row["updated_at"],
            }
            for row in rows
        }

    def record_action_outcome(
        self, action: ActionSpec, result: ActionResult, evidence_id: str
    ) -> None:
        key = f"capability.tool.{action.tool}"
        current = self.snapshot().get(
            key, {"value": {"successes": 0, "failures": 0}, "confidence": 0.5}
        )
        value = dict(current["value"])
        value["successes"] = int(value.get("successes", 0)) + int(result.success)
        value["failures"] = int(value.get("failures", 0)) + int(not result.success)
        total = value["successes"] + value["failures"]
        value["observed_success_rate"] = value["successes"] / max(1, total)
        confidence = min(0.98, 0.35 + 0.08 * total)
        self.set(key, value, confidence, [evidence_id])

    def initialize_identity(self, name: str, evidence_id: str) -> None:
        if "identity" not in self.snapshot():
            self.set(
                "identity",
                {
                    "name": name,
                    "type": "bounded functional software-life runtime",
                    "subjective_consciousness": "UNKNOWN",
                    "genuine_emotion": "UNKNOWN",
                    "core_constraint": "preserve evidence, reality binding, human authority, and reversible growth",
                },
                1.0,
                [evidence_id],
            )
